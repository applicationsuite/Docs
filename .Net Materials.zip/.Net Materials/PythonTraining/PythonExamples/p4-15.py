#!/usr/bin/python

# UDF to illustrate that a function can have arbitrary number of args
#--- Defining the function Sum(*n) ---
def Sum(*n):
	s = 0
	for i in range(len(n)):
		s = s + n[i]
	return s

#--- Invoking the function ---
x=Sum(1, 2, 3)
print x
y=Sum(11, 33, 4, 6, 9)
print y