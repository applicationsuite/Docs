#!/usr/bin/python

#--- Program to create Date objects with date validation
#--- Besides displaying the date in different formats.

import sys

cshort_month = ['', 'Jan', 'Feb', 'Mar', 'Apr',
                    'May', 'Jun', 'Jul', 'Aug',
		    'Sep', 'Oct', 'Nov', 'Dec' ]

clong_month =  ['', 'January', 'Febraury', 'March', 'April',
                    'May', 'June', 'July', 'August',
		    'September', 'October', 'November', 'December' ]


class Date:
	def __init__(self, d, m, y):
		self.Day = d
		self.Month = m
		self.Year = y

	def show_date(self):
		print "Date is : ", self.Day, "-", self.Month, "-", self.Year

	def british_format(self):
		print "Date in British Format : ", 
		print str(self.Day) + "-" + str(self.Month) + "-" + str(self.Year)

	def american_format(self):
		print "Date in American Format : ", 
		print str(self.Month) + "-" + str(self.Day) + "-" + str(self.Year)

	def short_date(self):
		global cshort_month
		print str(self.Day) + "-" + cshort_month[self.Month] + "-" + str(self.Year)

	def long_date(self):
		global clong_month
		print str(self.Day) + ", " + clong_month[self.Month] + " " + str(self.Year)

#--- End of class "Date" definition ---

maxdays = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

try:
	day = int(raw_input("Enter the day [1-31] :"))
	month = int(raw_input("Enter the month [1-12] :"))
	year = int(raw_input("Enter the year [YYYY] :"))
except ValueError, detail:
	print "Value Error : ", detail
	sys.exit()


#--- Validating the date ----
if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
	maxdays[2] = 29

try:
	if month < 1 or month > 12:
		raise ValueError('Invalid Month...')
	elif (day < 1 or day > maxdays[month]):
		raise ValueError('Invalid Day...')
	else:
		dt = Date(day, month, year)
		dt.show_date()
		dt.british_format()
		dt.american_format()
		dt.short_date()
		dt.long_date()

except ValueError, detail:
	print "Invalid Date...", detail
