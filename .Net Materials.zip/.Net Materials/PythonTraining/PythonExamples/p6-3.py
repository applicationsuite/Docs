#!/usr/bin/python

#--- Program to write the given phrases in a data file ---

#--- Open the file for processing ---
f = open('PHRASES.TXT', 'w+')

#--- Process the opened file ---
while True:
	phrase = raw_input("Enter the phrase:")
	f.write(phrase + "\n")

	proceed = raw_input("Another Phrase [Y/N] ")
	if proceed == 'n' or proceed == 'N' or proceed == 'No':
		break

#--- Close the opened file ---
f.close()