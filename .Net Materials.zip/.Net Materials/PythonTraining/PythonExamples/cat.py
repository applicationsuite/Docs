#!/usr/bin/python

#--- Program to simulate "cat" command of UNIX / Linux ---

import sys 
if len(sys.argv) != 2:
	print """
	Usage : cat.py  <file_name>
	"""
else:
	f = open(sys.argv[1], 'r')
	for line in f:
		print line,
	f.close()
