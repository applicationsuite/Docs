#!/usr/bin/python

# UDF by name Message(title, name, msg)

#--- Defining the function Message(title, name, msg) ---
def Message(title, name, msg):
	print "%s %s \n%s" % (title, name, msg)

#--- Invoking the function ---
Message(title='Mr.', name='Rohit Kumar Sharma', msg='Have a nice day!!!')
print
Message(name='Sheela', title='Miss', msg='Good Morning')
print
Message(msg='Good Bye', title='Mr.', name='Shiv')