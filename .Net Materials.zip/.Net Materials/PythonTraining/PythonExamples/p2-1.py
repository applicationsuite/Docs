#!/usr/bin/python

# Checking whether the given number is EVEN or ODD....

number  = int(raw_input("Enter a number :"))

if (number % 2 == 0):
	print "It is an EVEN number"
else:
	print "It is an ODD number"