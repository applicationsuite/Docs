#!/usr/bin/python

# Understanding Functional Programming Tools function - filter

list = []
N = int(raw_input("How many elements? "))

print "Enter %d numbers one-by-one :" % N
for i in range(N):
	list.append(int(raw_input("Data :")))

#-- Defining functions to be used with filter() ----
def odd(x): return x%2 != 0 
def even(x): return x%2 == 0

O = filter(odd, list)
E = filter(even, list)

print "ODD List:"
print O
print "Even List:"
print E