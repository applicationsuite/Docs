#!/usr/bin/python

# Country - President dictionary

mydic = { 'India':'A.Kalam', 'USA':'G. Bush', 'Pakistan':'P. Mushraf' }

while True:
	print """
		COUNTRIES & PRESIDENTS
		----------------------

		[a] Know the President
		
		[b] Show All Presidents

		[c] Remove a President

		[d] Quit

	"""
	choice = raw_input("Your Choice [a-d]  : ")

	if choice == 'a':
		ckey = raw_input("Enter Country Name:")
		if ckey in mydic:
			print "President is %s" % (mydic[ckey])
		else:
			print "Country %s not found in dictionary..." % ckey
	elif choice == 'b':
		print '='*25
		print "%-12s \t %-12s" % ('Country', 'President')
		print '-'*25
		for k, v in mydic.iteritems():
			print "%-12s \t %-12s" % (k, v)
		print '='*25
	elif choice == 'c':
		ckey = raw_input("Enter Country Name whose President needs to be removed:")
		del mydic[ckey]
		print "President removed from dictionary..."
	elif choice == 'd':
		break
	else:
		print "Invalid choice..."

		

          
