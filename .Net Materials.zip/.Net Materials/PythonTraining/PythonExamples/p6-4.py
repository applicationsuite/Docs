#!/usr/bin/python

#--- Program to read the content of a given text file ---

fname = raw_input("Enter File Name :")
#--- Open the file for processing ---
f = open(fname, 'r')

#--- Process the opened file ---
textline = f.readline()
while textline != '':
	print textline,
	textline = f.readline()

#--- Close the opened file ---
f.close()