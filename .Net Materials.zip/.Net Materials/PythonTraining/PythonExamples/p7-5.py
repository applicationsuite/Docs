#!/usr/bin/python

#--- Program to illustrate that Exception handler don't just handle
#--- exceptions which occur immediately, but also which occur in the
#--- function(s) which are invoked.  This is termed as INDIRECT 
#--- EXCEPTION



def this_fails(): 
	x = 1/0 

try: 
	this_fails() 
except ZeroDivisionError, detail: 
	print 'Handling run-time error:', detail 

