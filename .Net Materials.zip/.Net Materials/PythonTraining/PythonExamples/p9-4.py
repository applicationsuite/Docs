#!/usr/bin/python

# Obtaining System Information

import os, sys

while True:
	os.system('cls')
	print """

		System Information
		------------------
		1. Version Number
		2. Platform
		3. Name of Executable
		4. Exit


		"""
	num = int(raw_input("\t\tEnter UR Choice [1-4] "))

	if num == 1:
		print sys.version
	elif num == 2:
		print sys.platform
	elif num == 3:
		print sys.executable
	elif num == 4:
		sys.exit()
	else:
		print "Invalid Choice...."

	dummy = raw_input("Press ENTER to continue...")

print "How is that?"
