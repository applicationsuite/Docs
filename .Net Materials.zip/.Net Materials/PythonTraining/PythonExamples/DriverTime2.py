# Driver to test class Time Class with accessor functions.

from Time2 import Time

time1 = Time()

# print initial time
print "The initial time is",
time1.showTime()

# change time
time1.setTime( 13, 27, 6 )
print "\n\nTime after setTime is",
time1.showTime()

time1.setHour( 4 )
time1.setMinute( 3 )
time1.setSecond( 34 )
print "\n\nTime after setHour, setMinute, setSecond is",
time1.showTime()
