#!/usr/bin/python

#--- Program to simulate "env" or "set" command of UNIX / Linux ---

import sys
#--- Setting the sys.stdout file to "OUTPUT" data file ---
sys.stdout = open('OUTPUT', 'w')

print "Observe Redirection now"
print "How is that?"
