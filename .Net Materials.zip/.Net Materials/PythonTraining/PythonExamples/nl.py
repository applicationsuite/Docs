#!/usr/bin/python

#--- Program to simulate "nl" command of UNIX / Linux ---

import sys 
if len(sys.argv) != 2:
	print """
	Usage : nl.py  <file_name>
	"""
else:
	f = open(sys.argv[1], 'r')
	i=1
	for line in f:
		print "%3d %s" % (i,line),
		i = i + 1
	f.close()
