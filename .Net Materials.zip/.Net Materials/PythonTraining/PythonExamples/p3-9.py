#!/usr/bin/python

# ROMAN equivalent of a single digit number 
Number = int(raw_input("Enter a single digit number [1-9]:"))

Roman = {1:'I', 2:'II', 3:'III', 4:'IV', 5:'V', 
         6:'VI', 7:'VII', 8:'VIII', 9:'IX' }

if Number in Roman:
	print "The Roman equivalent of " + str(Number) + " is " + Roman[Number]
