# This is a comment

print "Welcome to PYTHON"