import re
    
searchString = "Testing pattern matches"
    
expression1 = re.compile( r"Test" )
expression2 = re.compile( r"^Test" )
expression3 = re.compile( r"Test$" )
expression4 = re.compile( r"\b\w*es\b" )
  
if expression1.match( searchString ):
	print '"Test" was found.'

if expression2.match( searchString ):
	print '"Test" was found at the beginning of the line.'

if expression3.match( searchString ):
	print '"Test" was found at the end of the line.'

result = re.findall( expression4, searchString )
  
if result:
	print 'There are %d words(s) ending in "es":' % \
	( len( result ) ),
   
	for item in result:
		print " " + item,
   
print