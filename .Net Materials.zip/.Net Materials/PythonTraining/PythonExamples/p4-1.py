#!/usr/bin/python

# UDF to display a simple message

#--- Defining the function message() ---
def message():
	print "Welcome to BANGALORE"
	print "Have a nice day!!!"


#--- Invoking the function message() ---
message()
