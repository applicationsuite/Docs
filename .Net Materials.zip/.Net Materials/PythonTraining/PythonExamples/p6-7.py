#!/usr/bin/python

#--- Program to illustrate command line arguments ---

import sys 
for i in range(0,len(sys.argv)): 
	print "sys.argv[%d] = %s" % (i, sys.argv[i]) 

print "Total number of arguments %d" % len(sys.argv)