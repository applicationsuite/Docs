#!/usr/bin/python

#--- Program to simulate "head" command of UNIX / Linux ---

import sys 
if len(sys.argv) > 3:
	print """
	Usage : head.py  [-n] <file_name>
	"""
else:
	#--- Determining whether the number of lines are specified or not ---
	if len(sys.argv) == 2:
		f = open(sys.argv[1], 'r')
		nol = 10
	elif len(sys.argv) == 3:
		f = open(sys.argv[2], 'r')
		nol = abs(int(sys.argv[1]))

	#--- Displaying the top few (or 10) lines of a given file ---
	i=1
	for line in f:
		print "%3d %s" % (i,line),
		if i == nol:
			break
		else:
			i = i + 1

	f.close()
