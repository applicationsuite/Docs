#!/usr/bin/python

# UDF to convert temp from *F to *C and vice-versa
#--- Formulae for convertion
#  *Celsius = ( 5.0 / 9.0 ) * ( Fahrenheit - 32.0 )
#  *Fahrenheit = (( 9.0 / 5.0 ) * Celsius ) + 32.0

#--- Defining the function convert_temp() ---
def convert_temp(Degrees, Type):
	if Type == 'F':
		return ( 5.0 / 9.0 ) * ( Degrees - 32.0 )
	elif Type == 'C':
		return (( 9.0 / 5.0 ) * Degrees ) + 32.0

#--- Invoking the function ---
prompt = """
Specify Type
--------------
F - Fahrenheit
C - Celsius
--------------
Your Choice :
"""
D = float(raw_input("Enter the degrees :"))
T = raw_input(prompt)

if T == 'F':
	print "The equivalent in Celsius is %f" % convert_temp(Degrees=D, Type=T)
elif T == 'C':
	print "The equivalent in Fahrenheit is %f" % convert_temp(Type=T, Degrees=D)
else:
	print "Invalid degree type..."
