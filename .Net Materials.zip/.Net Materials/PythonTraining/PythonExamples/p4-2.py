#!/usr/bin/python

# UDF to find the cube of a given number

#--- Defining the function cube() ---
def cube(n):
	return n ** 3


#--- Invoking the function cube() ---
print "Finding the cubes of numbers 1 to 5"

print '='*22
print "%-10s \t %-10s" % ('Number', 'Cube')
print '-'*22
for i in range(1,6):
	print "%4d \t\t %4d" % (i, cube(i))

print '='*22
