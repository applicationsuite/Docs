#!/usr/bin/python

list = []
N = int(raw_input("How many elements? "))

print "Enter " + str(N) + " numbers one-by-one :"
for i in range(N):
	list.append(int(raw_input("Data :")))

Data = int(raw_input("Enter data to search :"))

#--- Binary Seach ---
Found = False
Low = 0
High = N-1
while Low <= High:
	Mid = (Low + High) / 2
	if list[Mid] < Data:
		Low = Mid + 1
	elif list[Mid] > Data:
		High = Mid - 1
	elif list[Mid] == Data:
		Found = True
		Pos = Mid + 1
		break
else:
	print str(Data) + " not found..."

if Found:
	print str(Data) + " found at position " + str(Pos)