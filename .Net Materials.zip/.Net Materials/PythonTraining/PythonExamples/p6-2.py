#!/usr/bin/python

#--- Generating a formatted output using the string justification methods ---

print "Displaying the SQUARE and CUBE of the first ten numbers:"
print "--------------------------------------------------------"
print "Number Square   Cube"
print "--------------------"
for x in range(1, 11): 
	print repr(x).rjust(6), repr(x*x).rjust(6), 
	# Note trailing comma on previous line 
	print repr(x*x*x).rjust(6) 