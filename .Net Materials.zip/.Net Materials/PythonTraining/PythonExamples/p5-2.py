#!/usr/bin/python

#--- Using the DefaultArgs module which has the UDFs with default arguments ---
import DefaultArgs

while True:
	print """
		DefaultArgs Module
		------------------

		[1] simple_interest(P,T,R=10)
		
		[2] print_char(char='*', n=40)

		[3] QUIT

	"""
	choice = int(raw_input("Your Choice [1-3] : "))

	if choice == 1:
		P = long(raw_input("Enter Principle Amount :"))
		T = int(raw_input("Enter Time Period in years :"))
		ans = DefaultArgs.ask_ok('Want to enter Rate of Interest?')
		if ans:
			R = int(raw_input("Enter Rate of Interest :"))
			SI = DefaultArgs.simple_interest(P, T, R)
		else:
			SI = DefaultArgs.simple_interest(P, T)

		print "Simple Interest is %9.2f" % SI
	elif choice == 2:
		DefaultArgs.print_char()
		DefaultArgs.print_char('-')
		DefaultArgs.print_char('#', 25)
	elif choice == 3:
		break
	else:
		print "Invalid Choice..."

