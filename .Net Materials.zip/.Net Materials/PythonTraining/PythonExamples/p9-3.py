#!/usr/bin/python

# Accept absolute path from the user and perfrom the file tests:
#	Existence
#	Driectory
#	File
#	Size

import os.path, sys

abspth = raw_input("Enter absolute path :")
while True:
	os.system('cls')
	print """

		F I L E    T E S T
		------------------
		1. Exists
		2. Is Directory
		3. Is File
		4. Size If File
		5. Quit


		"""
	num = int(raw_input("\t\tEnter UR Choice [1-5] "))

	if num == 1:
		if os.path.exists(abspth):
			print "The Given File EXISTS"
		else:
			print "Given File NOT FOUND"
	elif num == 2:
		if os.path.isdir(abspth):
			print "It is a DIRECTORY"
		else:
			print "It is NOT a DIRECTORY"
	elif num == 3:
		if os.path.isfile(abspth):
			print "It is a REGULAR FILE"
		else:
			print "It is NOT a FILE"
	elif num == 4:
		if os.path.isfile(abspth):
			print "The size of the file is " , os.path.getsize(abspth), " bytes"
		else:
			print "It is NOT a REGULAR FILE"
	elif num == 5:
		sys.exit()
	else:
		print "Invalid Choice...."

	dummy = raw_input("Press ENTER to continue...")

print "How is that?"
