#!/usr/bin/python

# UDF to find the given year is a leap year or not

#--- Defining the function isleap() ---
def isleap(year):
	if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
		return True
	else:
		return False

#--- Calling the function ---
yy = int(raw_input("Enter a year : "))
if isleap(yy):
	print "%d is a Leap year" % yy
else:
	print "%d is Not a Leap Year" % yy

