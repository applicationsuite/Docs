#!/usr/bin/python

#--- Program to simulate "env" or "set" command of UNIX / Linux ---

import os 

for k,v in os.environ.iteritems():
	print "%s => %s" % (k,v)
