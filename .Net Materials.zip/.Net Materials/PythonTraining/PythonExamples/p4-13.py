#!/usr/bin/python

# UDF recursive function to get the Nth Fibonacci number
#--- Defining the function fibo(n) ---
def fibo(n):
	if n == 1:
		return 0
	elif n == 2:
		return 1
	elif n > 2:
		return fibo(n-1) + fibo(n-2)

#--- Invoking the function ---
N = int(raw_input("Enter value for N :"))
print
print "The first %d Fibonacci numbers are :" % N

for i in range(1, N+1):
	print fibo(i),

