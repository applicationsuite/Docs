#!/usr/bin/python

# Checking whether the given sides form a valid triangle or not....

a  = int(raw_input("Enter value for side 1 :"))
b  = int(raw_input("Enter value for side 1 :"))
c  = int(raw_input("Enter value for side 1 :"))

if ((a+b > c) or (b+c > a) or (c+a > b)):
	print "The sides form a valid triangle"
else:
	print "The sides do not form a valid triangle"