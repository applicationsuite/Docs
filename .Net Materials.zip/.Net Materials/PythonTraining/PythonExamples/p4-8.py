#!/usr/bin/python

# UDF to print char specified number of times
#--- Defining the function print_char() ---
def print_char(char='*', n=40):
	print char*n

#--- Invoking the function ---
print_char()
print_char('-')
print_char('#', 25)