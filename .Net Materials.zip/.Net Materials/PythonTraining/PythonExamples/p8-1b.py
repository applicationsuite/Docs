#!/usr/bin/python

#--- Defining a class by name "Person", Creating instances of it
#--- and displaying the data....

class Person:
	def __init__(self, n='', g='', a=0):
		self.Name = n
		self.Gender = g
		self.Age = a

	def Update(self, a):
		self.Age = a

	def Details(self):
		print "Name   : " + self.Name
		print "Gender : " + self.Gender
		print "Age    : " + str(self.Age)


#--- Creating Person Instances 
Manager = Person('Shiv', 'M', 38)
Trainer = Person('Mukthar', 'M', 41)
STrainer = Person('Sheela', 'F', 35)

#--- Displaying the data
Manager.Details()
Trainer.Details()
STrainer.Details()

Manager.Update(35)
Manager.Details()

print "Creating a Secretary Object..."
Secretary = Person()
Secretary.Details()
print "Check Secretary Details..."