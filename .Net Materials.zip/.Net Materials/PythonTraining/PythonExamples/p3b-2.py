#!/usr/bin/python

# Generating a HISTOGRAM

list = [4, -3, 7, -2, 5, 10, -6]

for i in range(len(list)):
	print "list[%d] : %3d =>" % (i, list[i]),
	for j in range(abs(list[i])):
		if list[i] > 0:
			print '+',
		else:
			print '-',
	print "\n"
