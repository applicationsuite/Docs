#!/usr/bin/python

cmonth  = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ]
maxdays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

month = int(raw_input("Enter the month [1-12] :"))
year  = int(raw_input("Enter the year YYYY :"))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
	maxdays[1] = 29

print "The maximum number of days in the month of " + cmonth[month-1] \
      + " for the year " + str(year) + " is " + str(maxdays[month-1])