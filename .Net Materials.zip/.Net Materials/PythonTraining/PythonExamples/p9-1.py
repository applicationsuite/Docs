#!/usr/bin/python

# Operating System Interface Example......
import os, sys

while True:
	os.system('cls')
	print """

		Operating System Options
		------------------------
		1. Clear Screen
		2. Date
		3. Time
		4. Current Directory
		5. Quit


		"""
	num = int(raw_input("\t\tEnter UR Choice [1-5] "))

	if num == 1:
		os.system('cls')
	elif num == 2:
		print "Current date is :",
		print os.system('date /T')
	elif num == 3:
		print "Current time is :",
		print os.system('time /T')
	elif num == 4:
		print "Current Directory is :",
		print os.getcwd()
	elif num == 5:
		sys.exit()
	else:
		print "Invalid Choice...."

	dummy = raw_input("Press ENTER to continue...")

print "How is that?"
