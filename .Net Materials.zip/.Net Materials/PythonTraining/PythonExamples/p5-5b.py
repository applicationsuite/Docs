#!/usr/bin/python

#--- Using the UDF module all function in the current symbol table ---
from UDF import *

while True:
	print """
		UDF Module
		----------

		[1] message()
		
		[2] cube(n)

		[3] isleap(year)

		[4] rev_num(n)

		[5] char_check(c)

		[6] QUIT

	"""
	choice = int(raw_input("Your Choice [1-6] : "))

	if choice == 1:
		message()
	elif choice == 2:
		number = int(raw_input("Enter a number :"))
		print "Cube of %d is %d" % (number, cube(number))
	elif choice == 3:
		yy = int(raw_input("Enter a year :"))
		if isleap(yy):
			print "%d is a LEAP YEAR" % yy
		else:
			print "%d is NOT a LEAP YEAR" % yy
	elif choice == 4:
		num = int(raw_input("Enter a number :"))
		rev = rev_num(num)
		if num == rev:
			print "%d is a PALINDROME" % num
		else:
			print "%d is a NOT a PALINDROME" % num
	elif choice == 5:
		char = raw_input("Enter a character :")
		char_check(char)
	elif choice == 6:
		break
	else:
		print "Invalid Choice..."

