#!/usr/bin/python

#--- Program to count the number of lines of the given text files ---
#--- passed as command line arguments 

import sys

for arg in sys.argv[1:]: 
  try: 
    f = open(arg, 'r') 
  except IOError: 
    print 'cannot open', arg 
  else: 
    print arg, 'has', len(f.readlines()), 'lines'
    f.close() 

