#!/usr/bin/python

#--- Program to read the Customer Details in a data file ---

#--- Open the file for processing ---
f = open('CUSTOMER.DAT', 'r')

record_length = len(f.readline())
f.seek(0)  # Moving to the BOF 

#--- Process the opened file ---
rec_num = int(raw_input('Enter record number :'))
f.seek((rec_num-1)*record_length + rec_num - 1, 0 )
record = f.readline()
print record

#--- Close the opened file ---
f.close()