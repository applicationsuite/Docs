#!/usr/bin/python

#--- Program to write the Customer Details in a data file ---

#--- Open the file for processing ---
f = open('CUSTOMER.DAT', 'a')

#--- Process the opened file ---
while True:
	#--- Accepting Customer Details
	ID = int(raw_input("Enter Customer ID:"))
	Name = raw_input("Enter Customer Name :")
	Age = int(raw_input("Enter Customer Age :"))

	CustRec = str(ID).rjust(4) + '~' + Name.ljust(15) + '~' + str(Age).rjust(3)
	f.write(CustRec + "\n")

	proceed = raw_input("Another Record [Y/N] ")
	if proceed == 'n' or proceed == 'N' or proceed == 'No':
		break

#--- Close the opened file ---
f.close()