#!/usr/bin/python

# UDF recursive function to find the factorial of a number
#--- Defining the function factorial(n) ---
def factorial(n):
	if n==0 or n==1:
		return 1
	else:
		return n*factorial(n-1)

# UDF recursive function to find the GCD
#--- Defining the function GCD(m,n) ---
def GCD(m,n):
	if m == n:
		return m
	elif m > n:
		return GCD(m-n, n)
	elif n > m:
		return GCD(m, n-m)

# UDF recursive function to get the Nth Fibonacci number
#--- Defining the function fibo(n) ---
def fibo(n):
	if n == 1:
		return 0
	elif n == 2:
		return 1
	elif n > 2:
		return fibo(n-1) + fibo(n-2)

# UDF to illustrate the game of Tower of Hanoi
#--- Defining the function Hanoi(n,p1, p2, p3) ---
def Hanoi(n,source, temp, destination):
	if n == 1:
		print "Move disk %d from %c to %c" % (n, source, destination)
	elif n > 1:
		Hanoi(n-1, source, destination, temp)	
		print "Move disk %d from %c to %c" % (n, source, destination)
		Hanoi(n-1, temp, source, destination)

# UDF to illustrate the game of Tower of Hanoi
# Moreover using a global variable to keep a count of the number of disk moves

count=0
#--- Defining the function Hanoi2(n,p1, p2, p3) ---
def Hanoi2(n,source, temp, destination):
	global count
	if n == 1:
		print "Move disk %d from %c to %c" % (n, source, destination)
		count = count + 1
	elif n > 1:
		Hanoi2(n-1, source, destination, temp)	
		print "Move disk %d from %c to %c" % (n, source, destination)
		count = count + 1
		Hanoi2(n-1, temp, source, destination)
