#!/usr/bin/python

# Illustrating the use of Function Renaming Mechanisum advantage

def double(n):
	return n*2

def triple(n):
	return n*3

def compute(fun, data):
	return fun(data)

#--- Invoking the function ---
#--- Also observe how we can pass function names as argument to
#--- another function

number = int(raw_input("Enter a number :"))
prompt = """
You want to double it or triple it [D/T] """
ans = raw_input(prompt)

if ans == 'D':
	print "Double of %d is %d" % (number, compute(double, number))
elif ans == 'T':
	print "Triple of %d is %d" % (number, compute(triple, number))
else:
	print "Invalid option..."