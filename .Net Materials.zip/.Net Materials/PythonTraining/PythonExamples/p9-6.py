#!/usr/bin/python

# Perform String Operations

import os, sys, string

str = raw_input("Enter a string :")

while True:
	os.system('cls')
	print """

		String Operations
		-----------------
		1. Find a Pattern
		2. Count a Pattern
		3. Find & Replace
		4. Exit


		"""
	num = int(raw_input("\t\tEnter UR Choice [1-4] "))

	if num == 1:
		pat = raw_input("Enter a pattern to search :")
		if string.find(str, pat) >= 0:
			print "Pattern FOUND"
		else:
			print "Pattern NOT FOUND"
	elif num == 2:
		pat = raw_input("Enter a pattern to count :")
		if string.find(str, pat) >= 0:
			print "Pattern FOUND", "occurs", string.count(str,pat), "times"
		else:
			print "Pattern NOT FOUND"
	elif num == 3:
		oldtext = raw_input("Find What? ")
		if string.find(str, oldtext) >= 0:
			newtext = raw_input("Replace With :")
			print "Text AFTER replacement:"
			print string.replace(str, oldtext, newtext)
		else:
			print "Couldn't Find...."
	elif num == 4:
		sys.exit()
	else:
		print "Invalid Choice...."

	dummy = raw_input("Press ENTER to continue...")

print "How is that?"

# String : This is a string of words
# Pattern: of / is
# Oldtext: string, Newtext: text