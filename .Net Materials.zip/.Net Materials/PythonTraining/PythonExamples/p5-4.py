#!/usr/bin/python

#--- Using the Recursion module which has the recursive UDFs ---
import Recursion

while True:
	print """
		Recursion Module
		----------------

		[1] Factorial of a number
		
		[2] Greatest Common Divisor

		[3] Fibonacci Series

		[4] Tower of Hanoi

		[5] Tower of Hanoi with Number of disk moves

		[6] QUIT

	"""
	choice = int(raw_input("Your Choice [1-6] : "))

	if choice == 1:
		number = int(raw_input("Enter a number :"))
		print "Factorial of %d is %d" % (number, Recursion.factorial(number))

	elif choice == 2:
		number1 = int(raw_input("Enter FIRST number :"))
		number2 = int(raw_input("Enter SECOND number :"))

		print "GCD of %d and %d is %d" % (number1, number2, Recursion.GCD(number1, number2))

	elif choice == 3:
		N = int(raw_input("Enter value for N :"))
		print
		print "The first %d Fibonacci numbers are :" % N

		for i in range(1, N+1):
			print Recursion.fibo(i),
	
	elif choice == 4:
		N = int(raw_input("Enter number of disks :"))
		Recursion.Hanoi(N,'A','B','C')

	elif choice == 5:
		N = int(raw_input("Enter number of disks :"))
		Recursion.Hanoi2(N,'A','B','C')
		print "Number of disk moves : %d" % Recursion.count

	elif choice == 6:
		break
	else:
		print "Invalid Choice..."
