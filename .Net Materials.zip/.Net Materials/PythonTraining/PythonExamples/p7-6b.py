#!/usr/bin/python

#--- Program to raise exception for invalid values for day and month
#--- of the date components
import sys

maxdays = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
date = []

date.append(int(raw_input("Enter the day [1-31] :")))
date.append(int(raw_input("Enter the month [1-12] :")))
date.append(int(raw_input("Enter the year [YYYY] :")))

day = date[0]
month = date[1]
year = date[2]

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
	maxdays[2] = 29

try:
	if month < 1 or month > 12:
		raise ValueError('Invalid Month...')
	elif (day < 1 or day > maxdays[month]):
		raise ValueError('Invalid Day...')
	else:
		print "It is a valid date...."
except ValueError, detail:
	print "Invalid Date...", detail
