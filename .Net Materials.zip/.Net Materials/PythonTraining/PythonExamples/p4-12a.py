#!/usr/bin/python

# UDF recursive function to find the GCD
#--- Defining the function GCD(m,n) ---
def GCD(m,n):
	if m == n:
		return m
	elif m > n:
		return GCD(m-n, n)
	elif n > m:
		return GCD(m, n-m)

#--- Invoking the function ---
number1 = int(raw_input("Enter FIRST number :"))
number2 = int(raw_input("Enter SECOND number :"))

lcm = (number1 * number2) / GCD(number1, number2)

print "LCM of %d and %d is %d" % (number1, number2, lcm)
