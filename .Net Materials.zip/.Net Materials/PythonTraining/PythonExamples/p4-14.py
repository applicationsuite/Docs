#!/usr/bin/python

# UDF to illustrate the game of Tower of Hanoi
#--- Defining the function Hanoi(n,p1, p2, p3) ---
def Hanoi(n,source, temp, destination):
	if n == 1:
		print "Move disk %d from %c to %c" % (n, source, destination)
	elif n > 1:
		Hanoi(n-1, source, destination, temp)	
		print "Move disk %d from %c to %c" % (n, source, destination)
		Hanoi(n-1, temp, source, destination)

#--- Invoking the function ---
N = int(raw_input("Enter number of disks :"))
Hanoi(N,'A','B','C')
