#!/usr/bin/python

queue = []
while True:
	print """
		QUEUE OPERATIONS
		----------------

		[a] Insert Into Queue
		
		[b] Delete From Queue

		[c] Display

		[d] Quit

	"""
	choice = raw_input("Your Choice [a-d]  : ")

	if choice == 'a':
		data = int(raw_input("Enter data to insert:"))
		queue.append(data)
	elif choice == 'b':
		if len(queue) != 0:
			data = queue.pop(0)
			print "Deleted Data is " + str(data)
		else:
			print "The queue is empty..."
	elif choice == 'c':
		if len(queue) != 0:
			print "The contents of the queue are:"
			print queue
		else:
			print "The queue is empty..."
	elif choice == 'd':
		break
	else:
		print "Invalid choice..."
	
