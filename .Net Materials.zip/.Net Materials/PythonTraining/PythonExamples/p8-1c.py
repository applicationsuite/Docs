#!/usr/bin/python

#--- Defining a class by name "Person", Creating instances of it
#--- and displaying the data....

import sys

class Person:
	def __init__(self, n='', g='', a=0):
		self.Name = n
		self.Gender = g
		self.Age = a

	def setName(self, n):
		self.Name = n

	def setGender(self, g):
		self.Gender = g

	def setAge(self, a):
		self.Age = a

	def Details(self):
		print "Name   : " + self.Name
		print "Gender : " + self.Gender
		print "Age    : " + str(self.Age)


#--- Creating Person Instances 
Manager = Person('Shiv', 'M', 38)
Trainer = Person('Mukthar', 'M', 41)
STrainer = Person('Sheela', 'F', 35)

#--- Displaying the data
Manager.Details()
Trainer.Details()
STrainer.Details()

Manager.setAge(35)
Manager.Details()

print "Creating a Secretary Object..."
Secretary = Person()
Secretary.Details()
print "Check Secretary Details..."


#--- Storing valid data in Person object ---
try:
	while True:
		Name = raw_input("Enter Person's Name :")
		if Name != '':
			break
		else:
			print "Name cannot be empty..."
except IOError, ValueError:
	print "Input or value error..."
	sys.exit()

try:
	while True:
		Age = int(raw_input("Enter Person's Age :"))
		if Age < 1 or Age > 99:
			print "Age should be between 1 and 99..."
		else:
			break
except ValueError, detail:
	print "Value Error :", detail
	sys.exit()

valid_gender = ['m', 'M', 'f', 'F']
try:
	while True:
		Gender = raw_input("Enter Person's Gender [M/F] :")
		if Gender not in valid_gender:
			print "Invalid Gender..."
		else:
			break
except IOError, ValueError:
	print "Input or Value error..."
	sys.exit()


#--- If all data is validated ---
P = Person(Name, Gender, Age)
P.Details()