#!/usr/bin/python

# UDF to find the type of the given character
#--- Defining the function char_check() ---
def char_check(c):
	if c >= 'A' and c <= 'Z':
		print "Upper case letter"
	elif c >= 'a' and c <= 'z':
		print "Lower case letter"
	elif c >= '0' and c <= '9':
		print "It is a digit"
	else:
		print "It is a special symbol"

#--- Invoking the function ---
char = raw_input("Enter any character :")

char_check(char)
