#!/usr/bin/python

#--- Program to read the content of a given text file ---
import sys

fname = raw_input("Enter File Name :")
#--- Open the file for processing ---
try:
	f = open(fname, 'r')
except IOError, (errno, strerror): 
   print "I/O error(%s): %s" % (errno, strerror)
   sys.exit()
except: 
   print "Unexpected error:", sys.exc_info()[0] 

#--- Process the opened file ---
textline = f.readline()
while textline != '':
	print textline,
	textline = f.readline()

#--- Close the opened file ---
f.close()