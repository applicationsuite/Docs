#!/usr/bin/python

stack = []
operators = ['+', '-', '*', '/' ]

postfix = raw_input("Enter a Postfix Expression :")

for i in range(len(postfix)):
	symbol = postfix[i]

	if symbol not in operators:
		stack.append(symbol)
	else:
		op2 = stack.pop()
		op1 = stack.pop()
		if symbol == '+':
			calc = float(op1) + float(op2)
		elif symbol == '-':
			calc = float(op1) - float(op2)
		elif symbol == '*':
			calc = float(op1) * float(op2)
		elif symbol == '/':
			calc = float(op1) / float(op2)
		stack.append(calc)

print "Answer :" + str(stack.pop())
