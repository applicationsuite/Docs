#!/usr/bin/python

# UDF to find the Simple Interest with default value for ROI as 10%
#--- Defining the function simple_interest() ---
def simple_interest(P, T, R=10):
	return ( P * T * R ) / 100

def ask_ok(prompt='Yes or no, please!'): 
	while True: 
		ok = raw_input(prompt) 
		if ok in ('y', 'yes'): return True 
		if ok in ('n', 'no'): return False 
		print "Please enter y / yes OR n / no only..."

#--- Invoking the function ---
P = long(raw_input("Enter Principle Amount :"))
T = int(raw_input("Enter Time Period in years :"))
ans = ask_ok('Want to enter Rate of Interest?')
if ans:
	R = int(raw_input("Enter Rate of Interest :"))
	SI = simple_interest(P, T, R)
else:
	SI = simple_interest(P, T)

print "Simple Interest is %9.2f" % SI