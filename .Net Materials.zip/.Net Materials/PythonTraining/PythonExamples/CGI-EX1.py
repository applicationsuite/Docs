#!c:\Python24\python.exe

import time
   
def printHeader( title ):
	print """Content-type: text/html
    
	<head><title>%s</title></head>
  
	<body>""" % title
   
printHeader( "Current date and time" )
print time.ctime( time.time() )
print "</body></html>"
