#!/usr/bin/python

#--- Generating a formatted output using the string justification methods ---

print "Displaying the SQUARE and CUBE of the first ten numbers:"
print "--------------------------------------------------------"
print
print "With LEFT Justification"
print "--------------------"
print "Number Square Cube"
print "--------------------"
for x in range(1, 11): 
	print repr(x).ljust(6), repr(x*x).ljust(6), 
	# Note trailing comma on previous line 
	print repr(x*x*x).ljust(6) 

print "--------------------"
print
print "With CENTER Justification"
print "--------------------"
print "Number Square Cube"
print "--------------------"
for x in range(1, 11): 
	print repr(x).center(6), repr(x*x).center(6), 
	# Note trailing comma on previous line 
	print repr(x*x*x).center(6) 
print "--------------------"
