#!/usr/bin/python

stack = []
while True:
	print """
		STACK OPERATIONS
		----------------

		[a] Push
		
		[b] Pop

		[c] Display

		[d] Quit

	"""
	choice = raw_input("Your Choice [a-d]  : ")

	if choice == 'a':
		data = int(raw_input("Enter data to push:"))
		stack.append(data)
	elif choice == 'b':
		if len(stack) != 0:
			data = stack.pop()
			print "Popped Data is " + str(data)
		else:
			print "The stack is empty..."
	elif choice == 'c':
		if len(stack) != 0:
			print "The contents of the stack are:"
			print stack
		else:
			print "The stack is empty..."
	elif choice == 'd':
		break
	else:
		print "Invalid choice..."
	
