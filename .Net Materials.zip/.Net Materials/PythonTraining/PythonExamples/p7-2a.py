#!/usr/bin/python

# Checking whether the given number is EVEN or ODD....

while True:
	try:
		number  = int(raw_input("Enter an integer :"))
		break
	except ValueError:
		print "Oops! That was not a valid integer. Try again..." 

if (number % 2 == 0):
	print "It is an EVEN number"
else:
	print "It is an ODD number"