#!/usr/bin/python

# UDF to illustrate the lambda function


mylist = range(25)

fun = lambda x: x%2 == 0
result = filter(fun, mylist)
print result