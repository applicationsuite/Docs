#!/usr/bin/python

# Understanding Functional Programming Tools function - map()

list = []
N = int(raw_input("How many elements? "))

print "Enter %d numbers one-by-one :" % N
for i in range(N):
	list.append(int(raw_input("Data :")))

#-- Defining functions to be used with map() ----
def odd(x): return x%2 != 0 
def even(x): return x%2 == 0
def double(x): return x * 2 

O = filter(odd, list)
E = filter(even, list)
D = map(double, list)

print "ODD List:"
print O
print "Even List:"
print E
print "Doubled List:"
print D