#!/usr/bin/python

# Accept absolute path from the user and find the following:
#	Drive Name
#	Driectory Name
#	File Name
#	Extenstion

import os.path, sys

abspth = raw_input("Enter absolute path :")
while True:
	os.system('cls')
	print """

		Path Manipulation
		-----------------
		1. Drive Name
		2. Directory Name
		3. File Name
		4. Extension
		5. Quit


		"""
	num = int(raw_input("\t\tEnter UR Choice [1-5] "))

	if num == 1:
		print os.path.splitdrive(abspth)
	elif num == 2:
		print os.path.dirname(abspth)
	elif num == 3:
		print os.path.basename(abspth)
	elif num == 4:
		print os.path.splitext(abspth)
	elif num == 5:
		sys.exit()
	else:
		print "Invalid Choice...."

	dummy = raw_input("Press ENTER to continue...")

print "How is that?"
