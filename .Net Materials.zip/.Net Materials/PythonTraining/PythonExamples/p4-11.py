#!/usr/bin/python

# UDF recursive function to find the factorial of a number

#--- Defining the function factorial(n) ---
def factorial(n):
	if n==0 or n==1:
		return 1
	else:
		return n*factorial(n-1)

#--- Invoking the function ---
number = int(raw_input("Enter a number :"))
print "Factorial of %d is %d" % (number, factorial(number))

#--- Finding Binomial Co-efficient ---
print "\n\n\n"
print "Computint Binomial Co-efficient nCr"
n = int(raw_input("Enter value for n :"))
r = int(raw_input("Enter value for r :"))

ncr = factorial(n) / ( factorial(n-r) * factorial(r) )

print "Binomial Co-efficient is %f" % ncr