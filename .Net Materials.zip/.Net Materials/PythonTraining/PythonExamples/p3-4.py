#!/usr/bin/python

list = []
N = int(raw_input("How many elements? "))

print "Enter " + str(N) + " numbers one-by-one :"
for i in range(N):
	list.append(int(raw_input("Data :")))

Data = int(raw_input("Enter data to search :"))

#---Linear Seach---
Found = False
for i in range(N):
	if Data == list[i]:
		Found = True
		Pos = i + 1
		break
else:
	print str(Data) + " not found..."

if Found:
	print str(Data) + " found at position " + str(Pos)