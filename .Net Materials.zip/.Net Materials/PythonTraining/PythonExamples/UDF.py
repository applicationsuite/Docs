#!/usr/bin/python

# UDF to display a simple message
#--- Defining the function message() ---
def message():
	print "Welcome to BANGALORE"
	print "Have a nice day!!!"

# UDF to find the cube of a given number
#--- Defining the function cube() ---
def cube(n):
	return n ** 3


# UDF to find the given year is a leap year or not
#--- Defining the function isleap() ---
def isleap(year):
	if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
		return True
	else:
		return False


# UDF to find the given number is a palindrome or not
#--- Defining the function rev_num() ---
def rev_num(n):
	rev = 0
	while n!= 0:
		digit = n % 10
		rev = rev * 10 + digit
		n = n / 10

	return rev

# UDF to find the type of the given character
#--- Defining the function char_check() ---
def char_check(c):
	if c >= 'A' and c <= 'Z':
		print "Upper case letter"
	elif c >= 'a' and c <= 'z':
		print "Lower case letter"
	elif c >= '0' and c <= '9':
		print "It is a digit"
	else:
		print "It is a special symbol"


