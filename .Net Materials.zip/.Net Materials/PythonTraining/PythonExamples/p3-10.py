#!/usr/bin/python

# Computing Net Pay using a dictionary 

empdb = { 101:12000, 102:10000, 103:15000,
          104:18000, 105:20000, 103:25000 }


empid = int(raw_input("Enter employee ID :"))

if empid in empdb:
	bs  = empdb[empid]
	hra = 0.20 * bs
	da  = 0.12 * bs
	pf  = 0.08 * bs
	net_pay = bs + hra + da - pf

	print "Employee ID : %d"    % (empid)
	print "Basic Salary: %9.2f" % (bs)
	print "H.R.A       : %9.2f" % (hra)
	print "D.A         : %9.2f" % (da)
	print "P.F         : %9.2f" % (pf)
	print "Net Pay     : %9.2f" % (net_pay)
else:
	print "Employee ID %d not found..." % (empid)
