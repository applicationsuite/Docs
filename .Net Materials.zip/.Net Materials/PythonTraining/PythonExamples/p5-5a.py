#!/usr/bin/python

#--- Using the UDF module partial list of functions ---
from UDF import cube, isleap

while True:
	print """
		Partial UDF Module
		------------------

		[1] cube(n)

		[2] isleap(year)

		[3] QUIT

	"""
	choice = int(raw_input("Your Choice [1-3] : "))

	if choice == 1:
		number = int(raw_input("Enter a number :"))
		print "Cube of %d is %d" % (number, cube(number))
	elif choice == 2:
		yy = int(raw_input("Enter a year :"))
		if isleap(yy):
			print "%d is a LEAP YEAR" % yy
		else:
			print "%d is NOT a LEAP YEAR" % yy

	elif choice == 3:
		break
	else:
		print "Invalid Choice..."
