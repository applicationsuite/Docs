# Driver Program for working with Time objects 
# existing in Time1.py Module
# Creating and manipulating objects of class Time.

from Time1 import Time  # import class definition from module

time1 = Time()  # create object of class Time

# access object's attributes
print "The attributes of time1 are: "
print "time1.hour:", time1.hour
print "time1.minute:", time1.minute
print "time1.second:", time1.second

# access object's methods
print "\nCalling method showTime:",
time1.showTime()

# change value of object's attributes
print "\n\nChanging time1's hour attribute..."
time1.hour = 25

print "\nCalling method showTime after alteration:",
time1.showTime()

