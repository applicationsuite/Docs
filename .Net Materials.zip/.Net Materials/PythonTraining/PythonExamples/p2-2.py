#!/usr/bin/python

# Checking whether the given year is a leap year or not....

year  = int(raw_input("Enter the year YYYY :"))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
	print "Leap Year"
else:
	print "Not a Leap Year"