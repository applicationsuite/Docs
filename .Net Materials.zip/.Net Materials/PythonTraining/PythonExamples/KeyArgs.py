#!/usr/bin/python

# UDF to convert temp from *F to *C and vice-versa
#--- Defining the function convert_temp() ---
def convert_temp(Degrees, Type):
	if Type == 'F':
		return ( 5.0 / 9.0 ) * ( Degrees - 32.0 )
	elif Type == 'C':
		return (( 9.0 / 5.0 ) * Degrees ) + 32.0

# UDF by name Message(title, name, msg)
#--- Defining the function Message(title, name, msg) ---
def Message(title, name, msg):
	print "%s %s \n%s" % (title, name, msg)

