#!/usr/bin/python

#--- Using the KeyArgs module which has UDFs ---
import KeyArgs

while True:
	print """
		KeyArgs Module
		--------------

		[1] convert_temp(Degrees, Type)
		
		[2] Message(title, name, msg)

		[3] QUIT

	"""
	choice = int(raw_input("Your Choice [1-3] : "))

	if choice == 1:
		prompt = """
			Specify Type
			--------------
			F - Fahrenheit
			C - Celsius
			--------------
			Your Choice :
			"""
		D = float(raw_input("Enter the degrees :"))
		T = raw_input(prompt)

		if T == 'F':
			print "The equivalent in Celsius is %f" % KeyArgs.convert_temp(Degrees=D, Type=T)
		elif T == 'C':
			print "The equivalent in Fahrenheit is %f" % KeyArgs.convert_temp(Type=T, Degrees=D)
		else:
			print "Invalid degree type..."

	elif choice == 2:
		KeyArgs.Message(title='Mr.', name='Rohit Kumar Sharma', msg='Have a nice day!!!')
		print
		KeyArgs.Message(name='Sheela', title='Miss', msg='Good Morning')
		print
		KeyArgs.Message(msg='Good Bye', title='Mr.', name='Shiv')

	elif choice == 3:
		break
	else:
		print "Invalid Choice..."



