#!/usr/bin/python

# UDF to find the Simple Interest with default value for ROI as 10%
#--- Defining the function simple_interest() ---
def simple_interest(P, T, R=10):
	return ( P * T * R ) / 100

def ask_ok(prompt='Yes or no, please!'): 
	while True: 
		ok = raw_input(prompt) 
		if ok in ('y', 'yes'): return True 
		if ok in ('n', 'no'): return False 
		print "Please enter y / yes OR n / no only..."

# UDF to print char specified number of times
#--- Defining the function print_char() ---
def print_char(char='*', n=40):
	print char*n

