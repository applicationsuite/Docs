#!/usr/bin/python

# UDF to find the given number is a palindrome or not

#--- Defining the function rev_num() ---
def rev_num(n):
	rev = 0
	while n!= 0:
		digit = n % 10
		rev = rev * 10 + digit
		n = n / 10

	return rev

#--- Calling the function ---
number = int(raw_input("Enter a number : "))
rnum   = rev_num(number)

if number == rnum:
	print "%d is a Palindrome" % number
else:
	print "%d is Not a Palindrome" % number
